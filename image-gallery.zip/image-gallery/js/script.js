/* ---------- DATA ----------
   Replace the "src" values with your own image paths (e.g. "images/photo1.jpg").
   "size" can be: "" (normal), "tall" or "wide". */
let IMAGES = [
  {title:"Misty Pine Ridge",   cat:"Nature", seed:"pine",     size:"tall"},
  {title:"Golden Valley",      cat:"Nature", seed:"valley",   size:"wide"},
  {title:"Quiet Lake",         cat:"Nature", seed:"lake",     size:""},
  {title:"Waterfall Trail",    cat:"Nature", seed:"waterfall",size:""},
  {title:"Neon Crossing",      cat:"City",   seed:"neon",     size:"tall"},
  {title:"Skyline at Dusk",    cat:"City",   seed:"skyline",  size:"wide"},
  {title:"Old Town Alley",     cat:"City",   seed:"alley",    size:""},
  {title:"Glass Towers",       cat:"City",   seed:"towers",   size:""},
  {title:"Desert Road",        cat:"Travel", seed:"desert",   size:"wide"},
  {title:"Mountain Pass",      cat:"Travel", seed:"pass",     size:"tall"},
  {title:"Harbour Morning",    cat:"Travel", seed:"harbour",  size:""},
  {title:"Island Shore",       cat:"Travel", seed:"island",   size:""},
  {title:"Fresh Fruit Bowl",   cat:"Food",   seed:"fruit",    size:""},
  {title:"Street Kitchen",     cat:"Food",   seed:"kitchen",  size:"wide"},
  {title:"Coffee and Pastry",  cat:"Food",   seed:"coffee",   size:"tall"},
  {title:"Spice Market",       cat:"Food",   seed:"spice",    size:""}
].map((d,i)=>({
  ...d, id:i,
  thumb:`https://picsum.photos/seed/${d.seed}/700/560`,
  src:`https://picsum.photos/seed/${d.seed}/1600/1100`
}));

/* ---------- ELEMENTS ---------- */
const $ = id => document.getElementById(id);
const grid=$('grid'), filtersEl=$('filters'), searchEl=$('search'),
      lb=$('lb'), lbImg=$('lbImg'), loader=$('loader');

let category='All', query='', visible=[], current=0;

/* ---------- FILTER BUTTONS ---------- */
function buildFilters(){
  const cats=['All',...new Set(IMAGES.map(i=>i.cat))];
  if(!cats.includes(category)) category='All';
  filtersEl.innerHTML=cats.map(c=>{
    const n=c==='All'?IMAGES.length:IMAGES.filter(i=>i.cat===c).length;
    return `<button class="chip ${c===category?'active':''}" data-cat="${esc(c)}" role="tab">${esc(c)}<small>${n}</small></button>`;
  }).join('');
  $('catList').innerHTML=cats.filter(c=>c!=='All').map(c=>`<option value="${esc(c)}">`).join('');
}
function esc(t){return String(t).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}

filtersEl.addEventListener('click',e=>{
  const b=e.target.closest('.chip'); if(!b) return;
  category=b.dataset.cat;
  filtersEl.querySelectorAll('.chip').forEach(c=>c.classList.toggle('active',c===b));
  render();
});
searchEl.addEventListener('input',()=>{query=searchEl.value.trim().toLowerCase();render();});

/* ---------- GRID ---------- */
function render(){
  visible=IMAGES.filter(i=>(category==='All'||i.cat===category)&&i.title.toLowerCase().includes(query));
  grid.innerHTML=visible.length?visible.map((img,i)=>`
    <figure class="card ${img.size}" style="--i:${i}" tabindex="0" data-index="${i}" aria-label="Open ${esc(img.title)}">
      <button class="del" data-id="${img.id}" aria-label="Delete photo" title="Delete">&times;</button>
      <img src="${img.thumb}" alt="${esc(img.title)}" loading="lazy">
      <span class="zoom"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/></svg></span>
      <figcaption class="info"><h3>${esc(img.title)}</h3><span>${esc(img.cat)}</span></figcaption>
    </figure>`).join(''):`<p class="empty">No photos found. Try a different word or category.</p>`;
}
grid.addEventListener('click',e=>{
  const del=e.target.closest('.del');
  if(del){removePhoto(del.dataset.id);return;}
  const c=e.target.closest('.card');if(c)open(+c.dataset.index);
});
grid.addEventListener('keydown',e=>{
  if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('card')){e.preventDefault();open(+e.target.dataset.index);}
});

/* ---------- LIGHTBOX ---------- */
function show(i,animate=true){
  current=(i+visible.length)%visible.length;
  const d=visible[current];
  const apply=()=>{
    loader.classList.add('on');
    const pre=new Image();
    pre.onload=pre.onerror=()=>{
      lbImg.src=d.src; lbImg.alt=d.title;
      loader.classList.remove('on'); lbImg.classList.remove('swap');
    };
    pre.src=d.src;
    $('lbTitle').textContent=d.title;
    $('lbMeta').textContent=d.cat;
    $('count').textContent=`${current+1} / ${visible.length}`;
    document.querySelectorAll('#thumbs img').forEach((t,k)=>{
      t.classList.toggle('on',k===current);
      if(k===current) t.scrollIntoView({inline:'center',block:'nearest',behavior:'smooth'});
    });
  };
  if(animate){lbImg.classList.add('swap');setTimeout(apply,200);}else apply();
}
function open(i){
  $('thumbs').innerHTML=visible.map((d,k)=>`<img src="${d.thumb}" alt="" data-k="${k}">`).join('');
  lb.classList.add('open');
  document.body.style.overflow='hidden';
  show(i,false);
  $('close').focus();
}
function close(){
  lb.classList.remove('open');
  document.body.style.overflow='';
  const card=grid.querySelector(`[data-index="${current}"]`); if(card) card.focus({preventScroll:true});
}
const next=()=>show(current+1), prev=()=>show(current-1);

$('next').onclick=next; $('prev').onclick=prev; $('close').onclick=close;
$('thumbs').addEventListener('click',e=>{const t=e.target.closest('img');if(t)show(+t.dataset.k);});
lb.addEventListener('click',e=>{if(e.target===lb)close();});
document.addEventListener('keydown',e=>{
  if(!lb.classList.contains('open')) return;
  if(e.key==='Escape') close();
  if(e.key==='ArrowRight') next();
  if(e.key==='ArrowLeft') prev();
});

/* Swipe on touch screens */
let sx=0;
lb.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;},{passive:true});
lb.addEventListener('touchend',e=>{
  const dx=e.changedTouches[0].clientX-sx;
  if(Math.abs(dx)>50) dx<0?next():prev();
},{passive:true});

/* ---------- SAVE YOUR OWN PHOTOS (IndexedDB: stays after refresh) ---------- */
const DB_NAME='gallery-db', STORE='photos';
function db(){
  return new Promise((res,rej)=>{
    const r=indexedDB.open(DB_NAME,1);
    r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});
    r.onsuccess=()=>res(r.result);
    r.onerror=()=>rej(r.error);
  });
}
async function tx(mode,fn){
  const d=await db();
  return new Promise((res,rej)=>{
    const t=d.transaction(STORE,mode), out=fn(t.objectStore(STORE));
    t.oncomplete=()=>res(out&&out.result);
    t.onerror=()=>rej(t.error);
  });
}
const HIDDEN_KEY='gallery-hidden-samples';
function getHidden(){try{return JSON.parse(localStorage.getItem(HIDDEN_KEY))||[];}catch(e){return [];}}
function toItem(rec){
  const url=URL.createObjectURL(rec.blob);
  return {id:rec.id,title:rec.title,cat:rec.cat,size:'',thumb:url,src:url,mine:true};
}
async function loadSaved(){
  try{
    const recs=await tx('readonly',s=>s.getAll());
    const hidden=getHidden();
    IMAGES=IMAGES.filter(i=>!hidden.includes(String(i.id)));
    IMAGES=IMAGES.concat((recs||[]).sort((a,b)=>a.added-b.added).map(toItem));
  }catch(err){console.warn('Saved photos could not be loaded',err);}
}

const addDlg=$('addDlg'), fileInput=$('fileInput');
let pending=[];
$('addBtn').onclick=()=>fileInput.click();
fileInput.onchange=()=>{
  pending=[...fileInput.files].filter(f=>f.type.startsWith('image/'));
  fileInput.value='';
  if(!pending.length) return;
  $('addInfo').textContent=pending.length===1?'1 photo selected.':pending.length+' photos selected. File names will be used as titles.';
  $('addTitle').value=''; $('addTitle').disabled=pending.length>1;
  addDlg.showModal();
};
$('addCancel').onclick=()=>{pending=[];addDlg.close();};
$('addForm').onsubmit=async()=>{
  const cat=$('addCat').value.trim()||'My Photos', title=$('addTitle').value.trim();
  for(const f of pending){
    const rec={
      id:'u'+Date.now()+Math.random().toString(36).slice(2,7),
      title:(pending.length===1&&title)||f.name.replace(/\.[^.]+$/,'').slice(0,40),
      cat, blob:f, added:Date.now()
    };
    try{await tx('readwrite',s=>s.put(rec));}catch(err){alert('Could not save '+f.name+'. Storage may be full.');continue;}
    IMAGES.push(toItem(rec));
  }
  pending=[]; category=cat; searchEl.value=''; query='';
  buildFilters(); render();
  window.scrollTo({top:0,behavior:'smooth'});
};
async function removePhoto(id){
  if(!confirm('Delete this photo from your gallery?')) return;
  const item=IMAGES.find(i=>String(i.id)===id); if(!item) return;
  if(item.mine){
    await tx('readwrite',s=>s.delete(id));
    URL.revokeObjectURL(item.src);
  }else{
    try{localStorage.setItem(HIDDEN_KEY,JSON.stringify([...getHidden(),String(item.id)]));}catch(e){}
  }
  IMAGES=IMAGES.filter(i=>String(i.id)!==id);
  buildFilters(); render();
}

if(navigator.storage&&navigator.storage.persist) navigator.storage.persist();
(async()=>{await loadSaved();buildFilters();render();})();